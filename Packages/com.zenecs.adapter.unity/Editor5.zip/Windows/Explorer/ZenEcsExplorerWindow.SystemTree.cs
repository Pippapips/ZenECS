#if UNITY_EDITOR
#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using ZenECS.Adapter.Unity;
using ZenECS.Adapter.Unity.Editor.Common;
using ZenECS.Core;
using ZenECS.Core.Systems;

namespace ZenECS.Adapter.Unity.Editor.Windows
{
    /// <summary>
    /// Left side systems tree panel of the ZenECS Explorer:
    /// - System group/phase tree
    /// - Unknown/Non-deterministic grouping
    /// - Integrates with Singletons section.
    /// </summary>
    public sealed partial class ZenEcsExplorerWindow
    {
        // =====================================================================
        //  SYSTEM TREE HELPERS
        // =====================================================================

        /// <summary>[Watch]의 AllOf 컴포넌트를 모두 가진 엔티티를 수집(항상 동작)</summary>
        public bool TryCollectEntitiesBySystemWatched(IWorld w, object system, List<Entity> outList)
        {
            var attrs = system.GetType().GetCustomAttributes(typeof(ZenSystemWatchAttribute), false)
                .Cast<ZenSystemWatchAttribute>().ToArray();
            if (attrs.Length == 0) return false;

            var all = w.GetAllEntities();
            foreach (var a in attrs)
            {
                var allOf = a.AllOf ?? Array.Empty<Type>();
                if (allOf.Length == 0) continue;

                foreach (var e in all)
                {
                    bool ok = true;
                    for (int i = 0; i < allOf.Length && ok; i++)
                    {
                        var component = allOf[i];
                        ok &= w.HasComponentBoxed(e, component);
                    }
                    if (ok) outList.Add(e);
                }
            }

            // 중복 제거(간단/할당 적음)
            if (outList.Count > 1)
            {
                var seen = new HashSet<int>(outList.Count);
                int write = 0;
                for (int i = 0; i < outList.Count; i++)
                    if (seen.Add(outList[i].Id))
                        outList[write++] = outList[i];
                if (write < outList.Count) outList.RemoveRange(write, outList.Count - write);
            }

            return true;
        }
        
        static void ResolveGroupAndPhase(Type t, out SystemGroup group, out PhaseKind phase)
        {
            group = SystemUtil.ResolveGroup(t);

            switch (group)
            {
                // 고정 틱 = Deterministic
                case SystemGroup.FixedInput:
                case SystemGroup.FixedDecision:
                case SystemGroup.FixedSimulation:
                case SystemGroup.FixedPost:
                    phase = PhaseKind.Deterministic;
                    break;

                // 프레임 기반 = Non-deterministic
                case SystemGroup.FrameInput:
                case SystemGroup.FrameSync:
                case SystemGroup.FrameView:
                case SystemGroup.FrameUI:
                    phase = PhaseKind.NonDeterministic;
                    break;

                default:
                    // 혹시 그룹이 지정 안돼있으면 Non-deterministic 쪽에 묶어두기
                    phase = PhaseKind.Unknown;
                    break;
            }
        }

        void DrawSystemTree(IReadOnlyList<ISystem> systems, IWorld? world)
        {
            // PhaseKind(Deterministic / NonDeterministic / Unknown)
            //  └ SystemGroup → (index, sys, type)
            var groupTree =
                new Dictionary<PhaseKind, Dictionary<SystemGroup, List<(int index, ISystem sys, Type type)>>>();

            for (int i = 0; i < systems.Count; i++)
            {
                var sys = systems[i];
                if (sys == null) continue;

                var t = sys.GetType();
                ResolveGroupAndPhase(t, out var group, out var phase);

                if (!groupTree.TryGetValue(phase, out var phaseMap))
                {
                    phaseMap = new Dictionary<SystemGroup, List<(int, ISystem, Type)>>();
                    groupTree[phase] = phaseMap;
                }

                if (!phaseMap.TryGetValue(group, out var list))
                {
                    list = new List<(int, ISystem, Type)>();
                    phaseMap[group] = list;
                }

                list.Add((i, sys, t));
            }

            // ─────────────────────────────────────────
            // 1. Deterministic
            // ─────────────────────────────────────────
            if (!groupTree.TryGetValue(PhaseKind.Deterministic, out var detGroups) ||
                detGroups.Values.All(l => l == null || l.Count == 0))
            {
                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUILayout.Foldout(false, "Deterministic", true, ZenGUIStyles.SystemFoldout);
                }
            }
            else
            {
                EditorGUI.indentLevel = 0;

                FoldoutHeader(ref _systemTree.DeterministicFold, "Deterministic", null, null, ZenGUIStyles.SystemFoldout);

                if (_systemTree.DeterministicFold)
                {
                    EditorGUI.indentLevel++;

                    DrawGroupLeaf(SystemGroup.FixedInput, "Input", detGroups, world, ZenGUIStyles.SystemFoldout);
                    DrawGroupLeaf(SystemGroup.FixedDecision, "Decision", detGroups, world, ZenGUIStyles.SystemFoldout);
                    DrawGroupLeaf(SystemGroup.FixedSimulation, "Simulation", detGroups, world, ZenGUIStyles.SystemFoldout);
                    DrawGroupLeaf(SystemGroup.FixedPost, "Post", detGroups, world, ZenGUIStyles.SystemFoldout);

                    EditorGUI.indentLevel--;
                }
            }

            EditorGUILayout.Space(4);

            // ─────────────────────────────────────────
            // 2. Non-deterministic
            // ─────────────────────────────────────────
            if (!groupTree.TryGetValue(PhaseKind.NonDeterministic, out var nonDetGroups) ||
                nonDetGroups.Values.All(l => l == null || l.Count == 0))
            {
                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUILayout.Foldout(false, "Non-deterministic", true, ZenGUIStyles.SystemFoldout);
                }
            }
            else
            {
                EditorGUI.indentLevel = 0;
                _systemTree.NonDeterministicFold =
                    EditorGUILayout.Foldout(_systemTree.NonDeterministicFold, "Non-deterministic", true, ZenGUIStyles.SystemFoldout);

                if (_systemTree.NonDeterministicFold)
                {
                    EditorGUI.indentLevel++;

                    // 2-1. Begin (Input + Sync)
                    bool hasBegin = HasAny(nonDetGroups, SystemGroup.FrameInput, SystemGroup.FrameSync);
                    if (hasBegin)
                    {
                        _systemTree.BeginFold = EditorGUILayout.Foldout(_systemTree.BeginFold, "Begin", true, ZenGUIStyles.SystemFoldout);
                        if (_systemTree.BeginFold)
                        {
                            EditorGUI.indentLevel++;
                            DrawGroupLeaf(SystemGroup.FrameInput, "Input", nonDetGroups, world, ZenGUIStyles.SystemFoldout);
                            DrawGroupLeaf(SystemGroup.FrameSync, "Sync", nonDetGroups, world, ZenGUIStyles.SystemFoldout);
                            EditorGUI.indentLevel--;
                        }
                    }

                    // 2-2. Late (View + UI)
                    bool hasLate = HasAny(nonDetGroups, SystemGroup.FrameView, SystemGroup.FrameUI);
                    if (hasLate)
                    {
                        _systemTree.LateFold = EditorGUILayout.Foldout(_systemTree.LateFold, "Late", true, ZenGUIStyles.SystemFoldout);
                        if (_systemTree.LateFold)
                        {
                            EditorGUI.indentLevel++;
                            DrawGroupLeaf(SystemGroup.FrameView, "View", nonDetGroups, world, ZenGUIStyles.SystemFoldout);
                            DrawGroupLeaf(SystemGroup.FrameUI, "UI", nonDetGroups, world, ZenGUIStyles.SystemFoldout);
                            EditorGUI.indentLevel--;
                        }
                    }

                    EditorGUI.indentLevel--;
                }
            }

            EditorGUILayout.Space(4);

            // ─────────────────────────────────────────
            // 3. Singletons
            // ─────────────────────────────────────────
            if (world != null)
            {
                IEnumerable<(Type type, Entity owner)>? singletons = null;
                try
                {
                    singletons = world.GetAllSingletons();
                }
                catch (Exception ex)
                {
                    // GetAllSingletons가 예외를 던져도 다른 UI에 영향을 주지 않도록 방어
                    Debug.LogException(ex);
                }

                if (singletons != null)
                {
                    var singletonList = singletons.ToList();
                    if (singletonList.Count > 0)
                    {
                        EditorGUI.indentLevel = 0;
                        _systemTree.SingletonsFold = EditorGUILayout.Foldout(_systemTree.SingletonsFold, "Singletons", true, ZenGUIStyles.SystemFoldout);
                        if (_systemTree.SingletonsFold)
                        {
                            EditorGUI.indentLevel++;
                            foreach (var (type, owner) in singletonList)
                            {
                                DrawSingletonRow(type, owner, world);
                            }

                            EditorGUI.indentLevel--;
                        }
                    }
                    else
                    {
                        using (new EditorGUI.DisabledScope(true))
                        {
                            EditorGUILayout.Foldout(false, "Singletons", true, ZenGUIStyles.SystemFoldout);
                        }
                    }
                }
                else
                {
                    using (new EditorGUI.DisabledScope(true))
                    {
                        EditorGUILayout.Foldout(false, "Singletons", true, ZenGUIStyles.SystemFoldout);
                    }
                }
            }
            else
            {
                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUILayout.Foldout(false, "Singletons", true, ZenGUIStyles.SystemFoldout);
                }
            }

            EditorGUILayout.Space(4);

            // ─────────────────────────────────────────
            // 4. Unknown (SystemGroup.Unknown)
            // ─────────────────────────────────────────
            if (!groupTree.TryGetValue(PhaseKind.Unknown, out var unknownGroups) ||
                unknownGroups.Values.All(l => l == null || l.Count == 0))
            {
                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUILayout.Foldout(false, "Unknown", true, ZenGUIStyles.SystemFoldout);
                }
            }
            else
            {
                EditorGUI.indentLevel = 0;
                _systemTree.UnknownFold = EditorGUILayout.Foldout(_systemTree.UnknownFold, "Unknown", true, ZenGUIStyles.SystemFoldout);

                if (_systemTree.UnknownFold)
                {
                    EditorGUI.indentLevel++;

                    // Unknown 하위는 루트 하나: Unknown 섹션 안에 바로 시스템 리스트
                    if (unknownGroups.TryGetValue(SystemGroup.Unknown, out var list) && list != null)
                    {
                        foreach (var (index, sys, type) in list)
                            DrawSystemRow(index, sys, type, world);
                    }
                    else
                    {
                        // 혹시 다른 그룹 키로 들어온 경우가 있으면 전부 flatten 해서 출력
                        foreach (var kv in unknownGroups)
                        {
                            var list2 = kv.Value;
                            if (list2 == null) continue;
                            foreach (var (index, sys, type) in list2)
                                DrawSystemRow(index, sys, type, world);
                        }
                    }

                    EditorGUI.indentLevel--;
                }
            }

            EditorGUI.indentLevel = 0;
        }

        void DrawSystemRow(int index, ISystem sys, Type tSys, IWorld? world)
        {
            var typeName = tSys.Name;

            bool hasEnabled = sys is ISystemEnabledFlag;
            bool enabledValue = hasEnabled && ((ISystemEnabledFlag)sys).Enabled;

            // === 한 줄 Rect 계산 ===
            var rowHeight = EditorGUIUtility.singleLineHeight + 4f;
            var rowRect = GUILayoutUtility.GetRect(0, rowHeight, GUILayout.ExpandWidth(true));

            // Indent 반영
            rowRect = EditorGUI.IndentedRect(rowRect);

            const float pauseW = 24f;
            const float iconW = 24f; // 돋보기 / X 공통 폭
            const float gap = 1f;

            // 왼쪽: Pause
            var pauseRect = new Rect(rowRect.x, rowRect.y, pauseW, rowRect.height);

            // 오른쪽 끝: X
            var delRect = new Rect(rowRect.xMax - iconW, rowRect.y, iconW, rowRect.height);

            // 그 왼쪽: 돋보기
            var pingRect = new Rect(delRect.x - gap - iconW, rowRect.y, iconW, rowRect.height);

            // 가운데: System 버튼
            float sysX = pauseRect.xMax + gap;
            float sysRight = pingRect.x - gap;
            float sysW = Mathf.Max(0f, sysRight - sysX);
            var sysRect = new Rect(sysX, rowRect.y, sysW, rowHeight);

            // ===== Pause (Enabled 토글) =====
            using (new EditorGUI.DisabledScope(!hasEnabled))
            {
                var btnRect = new Rect(
                    pauseRect.x,
                    pauseRect.y + 1f,
                    pauseRect.width,
                    pauseRect.height - 2f
                );

                var oldBg = GUI.backgroundColor;
                var oldCont = GUI.contentColor;

                if (hasEnabled && !enabledValue)
                {
                    GUI.backgroundColor = EditorGUIUtility.isProSkin
                        ? new Color(0.24f, 0.48f, 0.90f, 1f)
                        : new Color(0.20f, 0.45f, 0.90f, 1f);
                    GUI.contentColor = Color.white;
                }

                if (GUI.Button(btnRect, ZenGUIContents.IconPlus(), ZenGUIStyles.ButtonPadding))
                {
                    if (hasEnabled)
                    {
                        var flag = (ISystemEnabledFlag)sys;
                        flag.Enabled = !flag.Enabled;
                    }
                }

                GUI.backgroundColor = oldBg;
                GUI.contentColor = oldCont;
            }

            bool selected = _systemTree.SelectedSystemIndex == index;
            bool clicked = GUI.Toggle(sysRect, selected, typeName, ZenGUIStyles.ButtonMLNormal10);
            if (clicked && !selected)
            {
                ClearState();
                _systemTree.SelectedSystemIndex = index;
            }

            var pingBtnRect = new Rect(
                pingRect.x,
                pingRect.y + 1f,
                pingRect.width,
                pingRect.height - 2f
            );

            if (GUI.Button(pingBtnRect, ZenGUIContents.IconSearch(), ZenGUIStyles.ButtonPadding))
            {
                PingSystemTypeNoSelect(tSys);
            }

            // ===== X 삭제 버튼 =====
            using (new EditorGUI.DisabledScope(!_coreState.EditMode))
            {
                var delBtnRect = new Rect(
                    delRect.x,
                    delRect.y + 1f,
                    delRect.width,
                    delRect.height - 2f
                );

                var delContent = new GUIContent("X", "Remove this System from the current World");
                if (GUI.Button(delBtnRect, delContent, ZenGUIStyles.ButtonMCNormal10) && world != null)
                {
                    var sysName = tSys.Name;
                    if (EditorUtility.DisplayDialog(
                            "Remove System",
                            $"Remove system '{sysName}' from the current World?",
                            "Remove",
                            "Cancel"))
                    {
                        world.RemoveSystem(tSys);

                        ClearState();
                        GUIUtility.ExitGUI();
                    }
                }
            }
        }
        
        bool HasAny(Dictionary<SystemGroup, List<(int, ISystem, Type)>> map, params SystemGroup[] groups)
        {
            foreach (var g in groups)
            {
                if (map.TryGetValue(g, out var list) && list is { Count: > 0 })
                    return true;
            }

            return false;
        }

        void DrawGroupLeaf(
            SystemGroup group,
            string label,
            Dictionary<SystemGroup, List<(int index, ISystem sys, Type type)>> map,
            IWorld? world,
            GUIStyle foldStyle)
        {
            if (!map.TryGetValue(group, out var list) || list.Count == 0)
                return;

            if (!_systemTree.GroupFold.TryGetValue(group, out var open))
                open = true;

            open = EditorGUILayout.Foldout(open, label, true, foldStyle);
            _systemTree.GroupFold[group] = open;
            if (!open) return;

            int prevIndent = EditorGUI.indentLevel;
            EditorGUI.indentLevel++;

            foreach (var (index, sys, type) in list)
                DrawSystemRow(index, sys, type, world);

            EditorGUI.indentLevel = prevIndent;
        }
    }
}
#endif
